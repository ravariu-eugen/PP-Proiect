ReadMe

Task 1
    Mai intai, verificam daca exista o coloana cu numele dat.
    Apoi, sortam tabelul(fara prima linie) folosind sortBy.
    Functia de comparare va lua doua linii si le va compara valoara de pe coloana data. 
    Daca ambele sunt numere, le sorteaza in functie de valoarea lor numerica. 
    Altfel, le sorteaza lexicografic.
    Daca cele doua valori sunt egale, liniile vor fi sortate din nou in functie de prima coloana.

Task 2
    Verificam daca cele doua tabele au prima linie la fel.
    Daca nu, intoarcem primul tabel.
    Altfel, concatenam liniile celui de-al doilea tabel(fara prima) la sfarsitul primului.

Task 3
    Mai intai, adaugam linii goale( au doar valoarea "") la tabelul cu mai putine linii pana cand
ajung sa aiba aceasi lungime. Apoi, pentru fiecare linie din tabelul 2, 
o concatenam la sfarsitul liniei corespunzatoare din primul tabel.

Task 4
    Pentru fiecare linie din tabelul 1, verificam daca exista o linie in tabelul 2 cu aceeasi cheie pe coloana data.
    Daca da, imbinam liniile si o adaugam la tabelul final.

Task 5
    Mai intai, generam produsul cartezian de linii al celor doua tabele, 
dupa care aplicam functia data pe fiecare pereche.

Task 6
    Mai intai, transpunem tabelul.
    Apoi, eliminam din tabelul obtinut liniile ce nu au numele in lista de coloane data.
    La final, transpunem din nou tabelul.

Task 7
    Elinam liniile ce nu verifica conditia pentru valoarea de pe coloana data.