
Task1
    -compute_average_steps
    Calculez media valorilor pentru fiecare linie.
Task2
    -get_passed_people_num
    Pentru fiecare linie, calulez numarul de pasi, compar cu 1000 si adun 1 
pentru fiecare linie care indeplineste conditia.
    -get_passed_people_percentage
    Impart numarul de persoane care indeplinesc conditia anterioara la 
numarul total de persoane.
    -get_steps_avg
    Pentru fiecare linie, calulez numarul de pasi, apoi calculez media.
Task3
    -get_avg_steps_per_h
    Mai intai, transpun matricea, transformand coloanele in linii. Apoi, pentru
fiecare linie(ce reprezinta o ora) calcuez media. In final, transpun matricea la loc.
Task4
    -get_activ_summary
    Mai intai, transpunem matricea, pentru a procesa coloanele ca linii.
    Apoi, luam ultimele 3 linii si pentru fiecare 
    Luam ultimele 3 linii din tabel, si pentru fiecare calculam cate valori sunt in 
intervalele [0,50), [50,100) si [100,500)
Task5
    Luam primele 2 coloane si sortam liniile mai intai dupa numarul total de pasi, apoi dupa nume.
Task6
    Pentru fiecare linie, calculeaza media primelor 4 valori, ultimelor 4 valori si diferenta absoluta dintre ele
Task7

Task8
